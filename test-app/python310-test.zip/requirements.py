# No requirements.txt needed
# Uses Python standard library only