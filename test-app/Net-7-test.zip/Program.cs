// Program.cs
var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => Results.Content(
    "<h1>Hello from .NET 7.0!</h1><p><a href='/health'>Health check</a></p>",
    "text/html"));

app.MapGet("/health", () => new {
    status = "healthy",
    runtime = ".NET 7",
    checkedAt = DateTime.UtcNow
});

app.Run();