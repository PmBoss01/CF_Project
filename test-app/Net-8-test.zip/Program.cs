// Program.cs
var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => Results.Content(
    "<h1>Hello from .NET 8.0!</h1><p><a href='/info'>Info</a></p>",
    "text/html"));

app.MapGet("/info", () => new {
    runtime = ".NET 8.0",
    status = "running",
    time = DateTime.UtcNow.ToString("o"),
    dotnetVersion = Environment.Version.ToString()
});

app.Run();