# app.rb
require 'webrick'
require 'json'
require 'time'

PORT = (ENV['PORT'] || 8000).to_i

server = WEBrick::HTTPServer.new(Port: PORT, Logger: WEBrick::Log.new($stdout))

server.mount_proc '/' do |req, res|
  case req.path
  when '/status'
    res.content_type = 'application/json'
    res.body = JSON.generate({
      status: 'ok',
      runtime: "Ruby #{RUBY_VERSION}",
      time: Time.now.utc.iso8601
    })
  else
    res.content_type = 'text/html'
    res.body = '<h1>Hello from Ruby 3.2!</h1><p><a href="/status">Status</a></p>'
  end
end

trap('INT') { server.shutdown }

puts "Ruby 3.2 server on port #{PORT}"
server.start