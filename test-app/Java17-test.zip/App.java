// App.java
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.time.*;
import java.nio.charset.*;

public class App {
    public static void main(String[] args) throws Exception {
        int port = 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/", exchange -> {
            String path = exchange.getRequestURI().getPath();
            String body;
            String contentType;

            if ("/info".equals(path)) {
                body = """
                    {"runtime":"Java 17","status":"ok","time":"%s"}
                    """.formatted(Instant.now());
                contentType = "application/json";
            } else {
                body = "<h1>Hello from Java 17!</h1><p><a href='/info'>Info</a></p>";
                contentType = "text/html";
            }

            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        });

        server.start();
        System.out.println("Java 17 server running on port " + port);
    }
}